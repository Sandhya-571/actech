import React from 'react';
import AdminLayout from '../../components/layout/AdminLayout';
import Result from '../../components/lms/superadmin/courses/Result';

export default function ViewProjects() {
    return (
        <AdminLayout>
            <Result/>
        </AdminLayout>
    )
}