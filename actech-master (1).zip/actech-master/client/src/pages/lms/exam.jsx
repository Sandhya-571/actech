import React from 'react';
import AdminLayout from '../../components/layout/AdminLayout';
import Exam from '../../components/lms/superadmin/courses/exam';

export default function Viewexam() {
    return (
        <AdminLayout>
            <Exam/>
        </AdminLayout>
    )
}