import React from 'react'
import AddMentorComponents from '../../components/superadmin/usermanager/AddMentor.component'
const AddMentor = ({classes,children}) => {
    return(
        <div>
            <AddMentorComponents />
        </div>
    )
}
export default AddMentor;