import React from 'react'
// import Login from '../components/superadmin/usermanager/Login.component';
import Login from '../components/form/SuperAdminLogin';


const AdminLogin = ({ classes, children }) => {
    return (
        <>
            <Login />
        </>
    )
}
export default AdminLogin;